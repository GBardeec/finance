<?php $__env->startSection('content'); ?>
        <div id="app">
            <Index></Index>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\лара\fin\resources\views/index.blade.php ENDPATH**/ ?>