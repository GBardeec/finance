@extends('layouts.main')

@section('content')
        <div id="app">
            <Index></Index>
        </div>
@endsection
