<template>
    <div class="container">
        <footer>

            <div class="text-center p-4 mt-5" style="background-color: rgba(0, 0, 0, 0.05);">
                © 2023 Автор: М.И.Р.
            </div>
        </footer>
    </div>
</template>

<script>

export default {
    name: "IndexFooter",
};
</script>
